package project;
import java.util.*;

public class Playlist {
	
	
	ArrayList<Song> insideSong;//indeicates the songs inside this playlist
	int playlistPopularity;//indicates this playlist's popularity；
	
	
	//initial playlist
	Playlist(int p){
		this.playlistPopularity = p;
	}
	
	Playlist(int playlistPopularity, Song song) {
		this.insideSong.add(song);
		this.playlistPopularity = playlistPopularity;
		
	}
	
	public void loadPlaylistPopularity(String playlisttxt) {
		 String[] wordsArray = playlisttxt.split("\t");
		 playlistPopularity = Integer.parseInt(wordsArray[1]);
		 return;
	}
	
	public void updatesong(Song s){
		//System.out.println(s.songName);
		this.insideSong.add(s);
	}
	
	
	//读playlist.txt原文件，得到的是每一个playlist的string
	public ArrayList<Song> loadPlaylist(String playlisttxt, HashMap<Integer, Song> numTosong ) {
			//新建一个list作为返回
			 ArrayList<Song> res = new ArrayList<Song>();
			 String[] wordsArray = playlisttxt.split("\t");
			 String[] song = wordsArray[0].split("\\s+");
			 int[] playlist = new int[song.length];
			 int playlist_popularity = Integer.parseInt(wordsArray[1]);
			 for(int j = 0; j < song.length; j++) {
				 //找到playlist里面的歌曲编号
				 playlist[j] = Integer.parseInt(song[j]);
				 //在hashmap里面找到对应的歌曲，对歌曲的popularity进行更新
				 if (numTosong.containsKey(playlist[j])) {
					 numTosong.get(playlist[j]).updatesongPopularity(playlist_popularity);
					 //在最后输出的结果list里面添加歌曲
					 res.add(numTosong.get(playlist[j]));
				 }
			 }
			
			 return res;
	}
	/*
	Playlist(int playlistPopularity, Song song) {
		this.playlist = insert(song, this.playlist);
		this.playlistPopularity = playlistPopularity;
		
	}
	public ArrayList<Song> insert(Song song, ArrayList<Song> playlisthelper) {
		playlisthelper.add(song);
		return playlisthelper;
	}
	*/
	
}
