package project;
import java.util.*;


public class binary_insert {
	public static void main(String[] args){
		binary_insert bi = new binary_insert();
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(1);
		a.add(3);
		a.add(4);
		a.add(8);
		a.add(11);
		System.out.println("original array: " + a );
		ArrayList<Integer> b = bi.insert(7,a);
		System.out.println(b);
		ArrayList<Integer> c = bi.insert(10,b);
		System.out.println(c);
		} 
	
	public ArrayList<Integer> insert(int x, ArrayList<Integer> num){
		ArrayList<Integer> y = new ArrayList<Integer>();
		int index = insertHelper(x, 0, num.size() - 1, num);
		y.addAll(num);
		y.add(index, x);
		return y;
		}

	public int insertHelper(int x, int p, int q, ArrayList<Integer> num){
		int i = (p + q + 2)/2 - 1 ;
		if(p < q){	
			if(x < num.get(i)){
				i = insertHelper(x, p, i-1, num);
				return i;
				}
			else if(x > num.get(i)){
				i = insertHelper(x, i+1, q, num);
				return i;
				}
			else{
				return i;
				}
			}
		if(x > num.get(p)){
			return p + 1;		
			}
		else{
			return p;
			}
		}
}
