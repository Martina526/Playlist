package project;
import java.util.*;
import java.io.*;

public class Excute {
	
	ArrayList<Song> Songs = new ArrayList<Song>();
	ArrayList<Playlist> Playlists = new ArrayList<Playlist>();
	HashMap<Integer, Song> num2song = new HashMap<Integer, Song>(); 
	HashMap<Integer, Playlist> num2playlist = new HashMap<Integer, Playlist>();
	

	public static void main(String[] args) {
		try {
			Excute go = new Excute();
			go.pretreatSong("/Users/muyunyan/Documents/eeclipse/Playlist/PlaylistApp-Datasets/song_list.txt");
			go.loadFile("/Users/muyunyan/Documents/eeclipse/Playlist/PlaylistApp-Datasets/day00.txt");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void pretreatSong(String file) throws Exception{	
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String[] member;
		String c;	
		for (int i = 0; (c = br.readLine()) != null;i++){
			 member = c.split("\t");
			 Song s = new Song(member[1],member[2]);//initial a new song with "singer" & "name"
			 num2song.put(Integer.parseInt(member[0]), s);// key = song number, value = song object		 
		}
		br.close();
		fr.close();
	}
	
	// judge if this single playlist exist|| its pop < minimal, if not, then... 
	// update Playlists & num2playlist & each song's songinlist & its popularity
	public ArrayList<Playlist> loadSingle(String single){
		String[] member = single.split("\t");
		int pop = Integer.parseInt(member[1]);
		//System.out.println(member[1]);
		int minimum ;
		if(Playlists.size() == 0){
			minimum = 0;
		}
		else if(Playlists.size() >= 1024){
			minimum = Playlists.get(1024).playlistPopularity;
		}
		else{
			minimum = Playlists.get(Playlists.size() - 1).playlistPopularity;
		}
		
		if(pop >= minimum){
			Playlist pp = new Playlist(pop);
			String[] sss = member[0].split("\\s++");
			for(int i = 0; i < sss.length - 1; i++){
				Song s = num2song.get(Integer.parseInt(sss[i]));
				//System.out.println(Integer.parseInt(sss[i]));
				//System.out.println(s.Singer);
				pp.updatesong(s);
			}
			if(!Playlists.contains(pp)){				
				for(int i = 0; i < member.length - 1; i++){
					Song s = num2song.get(Integer.parseInt(member[i]));
					s.updatesongPopularity(pop);
					s.updatesonginList(num2playlist.size() + 1, pop, num2playlist);
					pp.updatesong(s);
				}
				num2playlist.put(num2playlist.size() + 1, pp);
				ArrayList<Playlist>Playlists = insertplaylist(pp, this.Playlists);
			}
			}
		return Playlists;
			
	}
	
	// load .txt file up to 128 lines
	public ArrayList<Playlist> loadFile(String file) throws Exception{
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String c;
		for (int i = 0; ((c = br.readLine()) != null) && (i<128);i++){			
			ArrayList<Playlist> Playlists = loadSingle(c);
		}
		br.close();
		fr.close();
		return Playlists;
		}

	//get these playlist's insong.get(i).name to show up the string name of songs in GUI
	public ArrayList<Playlist> topEight(){
		ArrayList<Playlist> p = new ArrayList<Playlist>();
		for(int i = 0; i < 8; i++){
			p.add(Playlists.get(i));
		}
		return p;	
	}
	
	
	
	
	
	
	public static ArrayList<Playlist> insertplaylist(Playlist x, ArrayList<Playlist> num){
		ArrayList<Playlist> y = new ArrayList<Playlist>();
		int index = insertHelper(x, 0, num.size() - 1, num);
		y.addAll(num);
		y.add(index, x);
		return y;
		}

	public static int insertHelper(Playlist x, int p, int q, ArrayList<Playlist> num){
		int i = (p + q + 2)/2 - 1 ;
		if(p < q){	
			if(x.playlistPopularity < num.get(i).playlistPopularity){
				i = insertHelper(x, p, i-1, num);
				return i;
				}
			else if(x.playlistPopularity > num.get(i).playlistPopularity ){
				i = insertHelper(x, i+1, q, num);
				return i;
				}
			else{
				return i;
				}
			}
		if(x.playlistPopularity  > num.get(p).playlistPopularity ){
			return p + 1;		
			}
		else{
			return p;
			}
		}
	/*
	// help tire to find the specific song's popularity
		public int getsongpop(int n){
			Song s = num2song.get(n);
			return s.songPopularity;
		}
	*/
		
}
	