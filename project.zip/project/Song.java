package project;

import java.util.*;

public class Song {
	
	String songName;
	String Singer;
	int songPopularity;
	ArrayList<inlist> songinList;
	
	public Song(String songName, String Singer) {
		this.songName = songName;
		this.Singer = Singer;
	}
	//刷新歌曲的pop值
	public void updatesongPopularity (int popularity) {
		songPopularity += popularity;
	}
	
	//更新歌曲所在的playlist的集合并排序
	public void updatesonginList (int num, int pop) {
		inlist i = new inlist(num, pop);
		//如果没有这个playlist则在list最后加入
		ArrayList<inlist> res = new ArrayList<inlist>();
		if (!songinList.contains(i)) {
			this.songinList = insert(i, songinList);
		} 	
		
	}
	
	// return the most popular playlist which this song exits in
	public int getMostPop(Song s){
		return s.songinList.get(0).num;
	}
	
	// help tire to find the specific song's popularity
		public int getsongpop(){
			return this.songPopularity;
		}
		
	//help tire to find the specific song's most popular playlist
	public Playlist getMostpopList(HashMap map){
		return (Playlist) map.get(this.songinList.get(0).num);
	}
	
	
	/*
	 * binary insert
	*/
	public static ArrayList<inlist> insert(inlist x, ArrayList<inlist> num){
		ArrayList<inlist> y = new ArrayList<inlist>();
		int index = insertHelper(x, 0, num.size() - 1, num);
		y.addAll(num);
		y.add(index, x);
		return y;
		}

	public static int insertHelper(inlist x, int p, int q, ArrayList<inlist> num){
		int i = (p + q + 2)/2 - 1 ;
		if(p < q){	
			if(x.pop < num.get(i).pop){
				i = insertHelper(x, p, i-1, num);
				return i;
				}
			else if(x.pop > num.get(i).pop ){
				i = insertHelper(x, i+1, q, num);
				return i;
				}
			else{
				return i;
				}
			}
		if(x.pop  > num.get(p).pop ){
			return p + 1;		
			}
		else{
			return p;
			}
		}
	
	private class inlist{
		int pop;
		int num;
		inlist(int p , int n){
			this.pop = p;
			this.num = n;
		}
	}
}
