package project;

import java.util.*;

public class Song {
	
	String songName;
	String Singer;
	int songPopularity;
	ArrayList<Integer> songinList;
	
	public Song(String songName, String Singer) {
		this.songName = songName;
		this.Singer = Singer;
	}
	//刷新歌曲的pop值
	public void updatesongPopularity (int popularity) {
		songPopularity += popularity;
	}
	
	//更新歌曲所在的playlist的集合并排序
	public void updatesonginList (int num, int pop, HashMap num2playlist) {
		this.songinList = insert(num, pop ,songinList, num2playlist);	
		
	}
	
	// help tire to find the specific song's popularity
		public int getsongpop(){
			return this.songPopularity;
		}
		
	//help tire to find the specific song's most popular playlist
	public Playlist getMostpopList(HashMap map){
		return (Playlist) map.get(this.songinList.get(0));
	}
	
	
	/*
	 * binary insert
	*/
	public static ArrayList<Integer> insert(int newplaylist, int x, ArrayList<Integer> num, HashMap num2playlist){
		ArrayList<Integer> y = new ArrayList<Integer>();
		int index = insertHelper(x, 0, num.size() - 1, num, num2playlist);
		y.addAll(num);
		y.add(index, newplaylist);
		return y;
		}

	public static int insertHelper(int x, int p, int q, ArrayList<Integer> num, HashMap num2playlist){
		int i = (p + q + 2)/2 - 1 ;
		if(p < q){	
			Playlist pli = (Playlist)num2playlist.get(num.get(i));
			if(x < pli.playlistPopularity){
				i = insertHelper(x, p, i-1, num, num2playlist);
				return i;
				}
			else if(x > pli.playlistPopularity ){
				i = insertHelper(x, i+1, q, num, num2playlist);
				return i;
				}
			else{
				return i;
				}
			}
		Playlist plp = (Playlist)num2playlist.get(num.get(p));
		if(x  > plp.playlistPopularity ){
			return p + 1;		
			}
		else{
			return p;
			}
		}
	/*
	private class inlist{
		int pop;
		int num;
		inlist(int p , int n){
			this.pop = p;
			this.num = n;
		}	
	}
	*/
}
