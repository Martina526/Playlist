package project_504;

import java.util.HashMap;
import java.util.Map;

public class suggesting {
	pretreatment pre = new pretreatment();
	//we implement the hashmap by setting the song's number as key and song's popularity as value
	public suggesting() {
		Map<Integer,Integer> mp = new HashMap<Integer,Integer>();
		for (int i = 0; i < 3168; i++) { 
			mp.put(i, 0);
		}
	}
	
}
