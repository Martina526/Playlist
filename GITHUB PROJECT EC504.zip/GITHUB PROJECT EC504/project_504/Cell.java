package project_504;

public class Cell {
	public int popularity;
	public int index;
	public int[] songs;
	
	public Cell(int popularity, int index, int[] songs) {
		this.popularity = popularity;
		this.index = index;
		this.songs = songs;
	}
}
