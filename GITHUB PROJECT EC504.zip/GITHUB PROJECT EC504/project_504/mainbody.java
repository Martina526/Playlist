package project_504;



import java.awt.EventQueue;
/*
 * Data Structure: HashMap, Prefix Tree (Trie);
 * 
 * Algorithm: quick sort, Depth First Searching(DFS); Recursion;
 * 
 * Problem: user's input is sensitive to upper and lower character 
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import java.io.FileOutputStream;  
import java.io.FileReader;  
import java.io.RandomAccessFile; 

import func.Cell;
import func.Vertex;
import func.trie;
import func.quickSort;
import func.find8thMinHeap;;

public class mainbody {

	public static void main(String[] args) throws Exception {
		//this three element is derived from the song_list.txt
		int[] SongNumber = new int[8162];   
        String[] SongName = new String[8162];
        String[] Author = new String[8162];
        //this two element is from play_list.txt
        int[][] playlist = new int[8126][128]; //the first index refers to the total lines of playlist
        									   //the second index means song number in the playlist	
        int[] playlist_popularity = new int[8126]; // it is the popularity of each song
        
		readFileByLines_song("/Users/Sony/Desktop/PlayListApp 2/PlaylistApp-Datasets/song_list.txt", SongNumber, SongName, Author);
		pretreatment pre = new pretreatment();
		readInFile("/Users/Sony/Desktop/PlayListApp 2/PlaylistApp-Datasets/1024playlist.txt", playlist, playlist_popularity);
		
		//we implement the hashmap by setting the song's number as key and song's popularity as value
		Map<Integer,Integer> mp = new HashMap<Integer,Integer>();
		for (int i = 0; i < 3168; i++) { 
			mp.put(i, 0);
		}
		// do the same thing build up the hashmap 
		for (int i = 0; i < playlist.length; i++) { 
			buildMap(mp, playlist[i], playlist_popularity[i]);
		}
		// this "trie" class is defined in the other package, we can use it directly by importing the package
		//we add all of the music into the trie in order to realising the searching function
		trie Trie = new trie(); 
		for (int i = 0; i < 3168; i++) { 
			//System.out.println("Song's name: " + SongName[i] + " Song's popularity: " + mp.get(i));
			Trie.addWord(SongName[i]);
		}
		//this map is used to store the selected songs and their popularity, we use the popularity as the key and name as value
		Map<Integer,String> selectedSongs = new HashMap<Integer,String>(); 
		//this list is used to store each selected song's popularity 
		List<Integer> findpopularity = new ArrayList<Integer>(); 
		 //find all related songs with prefix input by user("")
		List<String> relatedstrings =  Trie.listAllPossibleWords("Gucci");
		// Iterator all the songs with the same prefix 
		Iterator listiterator = relatedstrings.listIterator(); 
		while (listiterator.hasNext()) {
			 String s = (String) listiterator.next();
			 //System.out.println(s);
			 for (int j = 0; j < 3168; j++) {
				 if (SongName[j].equals(s)) {
					//get their popularity
					//build up a map: popularity as the key and Song's name as the value
					 findpopularity.add(mp.get(j)); 
					 selectedSongs.put(mp.get(j),SongName[j]); 
				 }
			 }
		}
		//System.out.println(selectedSongs);
		
		//set up an array in order to sort
		int[] array = new int[findpopularity.size()]; 
		for (int p = 0; p < findpopularity.size(); p++) {
			array[p] = findpopularity.get(p);
			//System.out.println(array[p]);
		}
		//***using quick sort algorithm to sort the popularity***
		array = quickSort(array); 
		
		for (int p = 0; p < array.length; p++) {
			System.out.println(array[p]);
			System.out.println(selectedSongs.get(array[p]));
		}
		

		//use the minheap function we can get the most popular 8 songlist's index
		//which means we can get the songlists and iteration of the song's number and name in the play list
		//
		int[] Top8thPlaylistIndex = new int[8];
		String[] output8thResult = {"", "", "", "", "", "", "", ""};
		Top8thPlaylistIndex = find8thMinHeap(playlist_popularity, playlist, 8);
		for(int i = 0;i < 8; i++) {
			//System.out.println(playlist[Top8thPlaylistIndex[i]].length);
			for (int j = 0; j < playlist[Top8thPlaylistIndex[i]].length; j++) {
				
				//System.out.println(playlist[Top8thPlaylistIndex[i]][j]);
				//System.out.println(SongName[playlist[Top8thPlaylistIndex[i]][j]]);
				output8thResult[i] = output8thResult[i].concat(playlist[Top8thPlaylistIndex[i]][j]+" ");
			}
			//output8thResult[i] = output8thResult[i].concat();
		}
		//System.out.println(output8thResult[0]);
		
		MyFile myFile = new MyFile();
        try {
            for (int i = 0; i < 8; i++) {
                myFile.creatTxtFile("test");
                myFile.writeTxtFile(output8thResult[i]);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		
		Top8thPlaylistIndex = find8thMinHeap(playlist_popularity, playlist, 1024);
		String[] sorted1024thResult = new String[1024];
		
		for(int i = 0;i < 1024; i++) {
			sorted1024thResult[i] = "";
			for (int j = 0; j < playlist[Top8thPlaylistIndex[i]].length; j++) {
				
				sorted1024thResult[i] =sorted1024thResult[i].concat(playlist[Top8thPlaylistIndex[i]][j]+" ");
			}
			//output8thResult[i] = output8thResult[i].concat();
		}
		//System.out.println(sorted1024thResult[1023]);
		
		MyFile sorted1024Playlists = new MyFile();
        try {
            for (int i = 0; i < 1024; i++) {
            	sorted1024Playlists.creatTxtFile("1024playlists");
            	sorted1024Playlists.writeTxtFile(sorted1024thResult[i]);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Layout window = new Layout();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
     * 
     * update the popularity of songs else initializing the hashmap by default value 0
     * @return
     */
	public static void buildMap(Map<Integer, Integer> mp, int[] song_list, int popularity) { 
		for (Integer song_num : song_list) {  
			if (mp.containsKey(song_num)) {  
				mp.put(song_num, mp.get(song_num) + popularity);  
	        } else {  
	            mp.put(song_num, 0);  
	        }  
	    }  
	    return;  
	}  
	
	/**
     * Read line by line to get the song'name, song's author and song's number
     * 
     * @return
     */
	public static void readFileByLines_song(String fileName, int[] SongNumber, String[] SongName, String[] Author) {
        File file = new File(fileName);
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int i = 0;
            while ((tempString = reader.readLine()) != null) {
                int j = 0;
                while(tempString.charAt(j) != '\t') {
                	j++;
                }
                String num = tempString.substring(0, j);
                SongNumber[i] = Integer.parseInt(num);
                j++;
                int n = j;
                while(tempString.charAt(n) != '\t') {
                	n++;
                }
                SongName[i] = tempString.substring(j, n);
                n++;
                int m = n;
                Author[i] = tempString.substring(m);
                i++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
        
    }
	
	/**
     * get the playlist from txt
     * 
     * @return
     */
	public static void readInFile(String file, int[][] playlist, int[] playlist_popularity) throws Exception{
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String[] wordsArray;
		String c;
		
		for (int i = 0; (c = br.readLine()) != null; i++){
			 wordsArray = c.split("\t");
			 
			 String[] song = wordsArray[0].split("\\s+");
			 
			 playlist[i] = new int[song.length];
			 for(int j = 0; j < song.length; j++) {
				 playlist[i][j] = Integer.parseInt(song[j]);
			 }
			 playlist_popularity[i] = Integer.parseInt(wordsArray[1]);
			 
		}
		br.close();
		fr.close();
		
	}
	/**
     * Quicksort Algorithm
     * 
     * @return
     */
	public static int[] quickSort (int[] array) {
		if (array == null || array.length == 0) return new int[0];
		quicksort (array, 0, array.length - 1);
		return array;
	}
	
	public static void quicksort (int[] array, int left, int right) {
		if (left >= right) return;
		
		int pivotIndex = partition (array, left, right);
		quicksort (array, left, pivotIndex - 1);
		quicksort (array, pivotIndex + 1, right);
	}
	
	public static int partition (int[] array, int left, int right) {
		int pivotPos = pivotPosition (left, right);
		int pivot = array[pivotPos];
		swap (array, pivotPos, right);
		int leftbound = left;
		int rightbound = right - 1;
		while (leftbound <= rightbound) {
			if (array[leftbound] > pivot) {
				leftbound++;
			} else if (array[rightbound] <= pivot) {
				rightbound--;
			} else {
				swap(array, leftbound++, rightbound--);
			}
		}
		swap(array, leftbound, right);
		return leftbound;
		
		
	}
	
	public static int pivotPosition (int left, int right) {
		int pivot = left +  (int)(Math.random() * (right - left +1));
		return pivot;
	}
	
	public static void swap (int[] array, int left, int right) {
		int temp = array[right];
		array[right] = array[left];
		array[left] = temp;
	}
	
	/**
     * Minheap data structure to get the 8 most popular list 
     * the time complexity of this function is O(nlongk), which n means the total number of the playlists,
     * k means the total number of playlists you want(8 or 1024)
     * 
     * @return
     */
	public static int[] find8thMinHeap(int[] popularity, int[][] playlist, int k) {
		//We shall find the 8th most popular playlists 
		if (popularity.length < k) {
			k = popularity.length;
		}
		//initializing a minHeap to store the top 8 playlist
		PriorityQueue<Cell> minHeap = new PriorityQueue<Cell>(k, new Comparator<Cell>(){
			@Override
			public int compare (Cell o1, Cell o2){
				if (o1.popularity == o2.popularity) return 0;
				else return o1.popularity < o2.popularity ? -1 : 1;
			}
		});
		//first of all, we offer 8 playlist to the minHeap
		//after that, when a new playlist offered, we will compare it with the peek
		//if the offered one is bigger than the peek, then we remove the peek and offer this playlist
		
		for (int i = 0; i < popularity.length; i++) {
			if (i < k) {
				minHeap.offer(new Cell(popularity[i], i ,playlist[i]));
			} else if (popularity[i] > minHeap.peek().popularity) {
				minHeap.poll();
				minHeap.offer(new Cell(popularity[i], i ,playlist[i]));
			}
		}
		int[] res = new int[k];
		for (int j = k - 1; j >= 0; j--) {
			res[j] = minHeap.poll().index;
			//System.out.println(res[j]);
		}
		return res;
		
	}
}
